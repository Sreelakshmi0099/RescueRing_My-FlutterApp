import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class MedicalCertificatePage extends StatefulWidget {
  const MedicalCertificatePage({Key? key}) : super(key: key);

  @override
  State<MedicalCertificatePage> createState() => _MedicalCertificatePageState();
}

class _MedicalCertificatePageState extends State<MedicalCertificatePage> {
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _bloodGroupController = TextEditingController();
  final TextEditingController _allergiesController = TextEditingController();
  final TextEditingController _medicalStateController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // Simulate refreshing data
  Future<void> _handleRefresh() async {
    await Future.delayed(Duration(seconds: 2)); // Simulate network delay
    Fluttertoast.showToast(
      msg: "Loading",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.blue,
      textColor: Colors.white,
    );
    // You might want to fetch or reload data here
  }

  Future<void> _submitMedDetails() async {
    if (_formKey.currentState!.validate()) {
      final user = FirebaseAuth.instance.currentUser;
      final patientId = user?.uid;

      if (patientId != null) {
        try {
          await FirebaseFirestore.instance
              .collection('patients')
              .where('patient_id', isEqualTo: patientId)
              .get()
              .then((querySnapshot) {
            if (querySnapshot.docs.isNotEmpty) {
              final docId = querySnapshot.docs.first.id;
              FirebaseFirestore.instance
                  .collection('patients')
                  .doc(docId)
                  .update({
                'age': _ageController.text,
                'blood': _bloodGroupController.text,
                'allergies': _allergiesController.text,
                'medicalstate': _medicalStateController.text,
              });
              Fluttertoast.showToast(
                msg: "Helath Data updated successfully",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.BOTTOM,
                backgroundColor: Colors.green,
                textColor: Colors.white,
              );
            }
          });
        } catch (e) {
          Fluttertoast.showToast(
            msg: "Error",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.red,
            textColor: Colors.white,
          );
          print('Error updating document: $e');
        }
      } else {
        Fluttertoast.showToast(
          msg: "User ID is null",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
        );
        print('User ID is null');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(''),
        backgroundColor: Colors.redAccent,
      ),
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 20),
            const Text(
              'Health Data',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 25,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _ageController,
              decoration: const InputDecoration(
                labelText: "Enter Age",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _bloodGroupController,
              decoration: const InputDecoration(
                labelText: "Enter Blood Group",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _allergiesController,
              decoration: const InputDecoration(
                labelText: "Enter Allergies",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _medicalStateController,
              decoration: const InputDecoration(
                labelText: "Medical Condition",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _submitMedDetails, // Correct function to call
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(home: MedicalCertificatePage()));
}
